Rails.application.routes.draw do
  resource :session,
    controller: "auth/sessions",
    only: [:create]

  resources :passwords,
    controller: "auth/passwords",
    only: [:create, :new]

  resources :users,
    controller: "auth/users",
    only: Clearance.configuration.user_actions do
    resource :password,
             controller: "auth/passwords",
             only: [:create, :edit, :update]
  end

  get "/session" => "auth/sessions#new", as: "sign_in"
  get "/sign_out" => "auth/sessions#destroy", as: "sign_out"

  get "/users" => "auth/users#new", as: "sign_up"

  root to: "dashboard#index", as: :signed_in_root
end
