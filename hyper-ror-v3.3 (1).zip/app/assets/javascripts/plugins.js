//= require apexcharts/dist/apexcharts.min.js
//= require admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js
//= require admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js