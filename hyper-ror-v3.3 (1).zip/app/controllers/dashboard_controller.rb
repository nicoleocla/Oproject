class DashboardController < ApplicationController
  before_action :require_login
  
  def index
  end
end
