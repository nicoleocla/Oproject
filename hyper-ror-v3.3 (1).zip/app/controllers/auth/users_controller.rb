module Auth
  class UsersController < Clearance::UsersController
    layout "non-auth"

    def new
      @user = User.new
      render template: "users/new"
    end

    def create
      @user = user_from_params

      if @user.save
        sign_in @user
        redirect_back_or url_after_create
      else
        flash.now.alert = "Bad name, email and password"
        render template: "users/new"
      end
    end

    private

    def user_params
      params.require(:user).permit(:name, :email, :password)
    end
  end
end
