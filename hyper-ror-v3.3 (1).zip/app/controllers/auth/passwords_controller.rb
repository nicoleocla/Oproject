module Auth
  class PasswordsController < Clearance::PasswordsController
    layout "non-auth"

    def new
      render template: "passwords/new"
    end

    def create
      if user = find_user_for_create
        user.forgot_password!
        deliver_email(user)
      else
        flash.now.alert = "Sorry, we could not find any user matching with provided email"
      end

      render template: "passwords/create"
    end
  end
end
