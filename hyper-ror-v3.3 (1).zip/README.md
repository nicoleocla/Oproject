# Hyper - Ruby on Rails (Getting Started)

Make sure to have Ruby (> v2.5) installed and running on your system. If you are having Ubuntu installed on your system, [this guide](https://www.digitalocean.com/community/tutorials/how-to-install-ruby-on-rails-with-rbenv-on-ubuntu-16-04) would help you to setup ruby and rails on your system.

Once you have installed the Ruby, make sure to install Rails. You can refer to official [guilde](https://guides.rubyonrails.org/getting_started.html).

The next step is to install Yarn (if not installed already). You can refer to installation guide available [here](https://yarnpkg.com/en/docs/install)


Once done, please follow below steps in order to get started with it:

* Open terminal, go to the folder and run command `bundle`
* Run command `yarn install` to install all frontend dependencies
* Migrate database using command `rails db:migrate`
* Now you are ready to start development server and project, run command `rails s` to start development server.


### Important Notes:
* We have covered authentication and other account related pages including registration, forget password, etc and provided as part of this seed project.
* All the required assets including stylesheets, javascripts etc are already available and setup. You just need to build out new pages as per your requirement.
* While creating new page (view), make sure to use the same html from original theme in order to have same experience.


### Support:
We are committed to our customers and support is at up most priority. If you have any question, issue with Hyper, please fill free to contact us anytime by filing the support form on our [website](https://coderthemes.com/#contact) or via email at [support@coderthemes.com](support@coderthemes.com). 
